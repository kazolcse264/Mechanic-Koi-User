package com.example.mechanic_koi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
